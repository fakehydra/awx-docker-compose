# awx-docker-compose
####  docker-compose.yml for ansible-awx 
